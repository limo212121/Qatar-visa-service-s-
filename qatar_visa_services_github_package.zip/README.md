
# Qatar Visa Services Website

This is a simple professional landing page for **Qatar Visa Services**.

## How to Deploy on GitHub Pages

1. Create a free account at [GitHub](https://github.com).
2. Create a new **public repository** (example: `qatar-visa-services`).
3. Upload the content of this repository (index.html and README.md) into your GitHub repository.
4. Go to **Settings → Pages**.
5. Under **Branch**, select `main` and `/ (root)` folder.
6. Click **Save**.

GitHub will provide you with your website link. 🎉

---

## Contact Form Setup

- Sign up at [Formspree.io](https://formspree.io/).
- Get your **Form ID** after creating a new form.
- Edit `index.html` file and replace:

```
<form action="https://formspree.io/f/YOUR_FORM_ID_HERE" method="POST">
```

with your real Formspree URL.

---

## Live Features

- Mobile responsive
- SEO ready
- Contact form (via Formspree)
- WhatsApp floating chat button
- Pricing & services sections
